⭐ Star Tic-Tac-Toe ⭐
🎮 About
Welcome to Star Tic-Tac-Toe, my fun twist on the classic game for the Programming Language and C++ Practice course (YN3012140116)! I built this game to practice C++ and make something unique. You and a friend enter your names, pick a 3x3 or 4x4 board, answer quick math questions to place your X or O, and race to win 3 rounds. The star-themed board, undo moves, move history, and score tracking make it special. I’m really proud of how it turned out! 🚀
🛠️ Prerequisites
To run my game, you’ll need:

A C++ compiler (e.g., g++, Clang, MSVC) that supports C++11 or newer.
The make utility for easy compilation with the Makefile.
Supported platforms: Windows (MinGW/MSYS2 recommended), Linux, macOS.

📂 Project Structure
I kept the code simple with just a few files:



File
What It Does



main.cpp
Starts the game and handles player input.


game.h
Lists all functions and the Move struct.


game.cpp
Contains board logic, math quiz, UI, and game rules.


Makefile
Makes compiling super easy!


🌟 Features
Here’s what makes my game stand out:

Personalized Names: Enter your names for a custom experience! 👤
Flexible Board: Choose 3x3 (3 in a row to win) or 4x4 (4 in a row). 🟦
Math Quiz: Answer a quick addition question to make a move. 🧮
Random Start: Each round randomly picks who goes first. 🎲
Star-Themed Board: A cool ASCII board with stars and dashes. ⭐
Undo Moves: Type u to undo your last move. ↩️
Move History: Type h to see all moves. 📜
Scoreboard: Tracks wins and win percentages. 📊
Error Logging: Saves mistakes with a unique game ID for debugging. 🐞
Cross-Platform: Works on Windows, Linux, and macOS. 🌍

🔨 Compilation

Put main.cpp, game.h, game.cpp, and Makefile in one folder.
Open a terminal in that folder.
Run:make

This creates tictactoe (or tictactoe.exe on Windows).

Compilation Troubleshooting

Compiler Errors: If it doesn’t compile, add -std=c++11 to your compiler flags (e.g., g++ -std=c++11).
Missing Files: Make sure all four files are in the folder.
No make: Install make (e.g., sudo apt install make on Ubuntu, or use MinGW/MSYS2 on Windows).

🎮 Running the Game
Run the executable:

Linux/macOS:./tictactoe


Windows:tictactoe.exe



🕹️ How to Play

Start the game and read the rules.
Enter player names for X and O.
Choose board size (3 for 3x3, 4 for 4x4).
Each turn:
Answer a math question (e.g., “Quick math: 4 + 5 = ?”).
Type u to undo, h for move history, or enter row and column numbers (e.g., 1 2).


Win a round by getting 3 (3x3) or 4 (4x4) marks in a row, column, or diagonal.
First to win 3 rounds wins the match!
Check the scoreboard for stats.
Choose y to play another round or n to quit.

Game Commands

1-3/4: Row or column numbers to place your X or O.
u: Undo the last move.
h: Show move history.
y/n: Play another round or exit.

🧹 Cleaning Up
To remove compiled files:
make clean

🧪 Testing the Game
I tested it on [your platform, e.g., Windows/Linux] to make sure it works! Here’s how you can test:

Run the game and try both 3x3 and 4x4 boards.
Test the quiz by answering correctly and incorrectly.
Use u to undo moves and h to check history.
Enter invalid inputs (e.g., letters, out-of-range numbers) to see error messages.
Play multiple rounds to check the scoreboard and match winner.
Look at the error log at the end if you made mistakes.

📝 Code Maintenance Notes

Memory: I carefully free the board’s memory to avoid leaks.
Errors: Invalid inputs (e.g., wrong row, occupied cell) are caught and logged with a game ID.
Platform: Screen clearing works on Windows (cls) and Linux/macOS (clear).
Simple Code: Uses basic C++ (arrays, vectors, functions) so it’s easy to understand.

⚠️ Troubleshooting

Board Looks Weird: Check your terminal’s font (try a monospaced font like Consolas).
Input Issues: Only enter numbers in the range (1-3 for 3x3, 1-4 for 4x4).
Quiz Skips: Make sure to enter a number for math questions.
Compilation Warnings: Update your compiler or add -std=c++11 if you see C++11 errors.
Game Crashes: Double-check all files are present and run make clean then make.

📬 Submitting to GitHub

Create a Mid-term-project folder in your GitHub repository.
Add main.cpp, game.h, game.cpp, Makefile, and this README.md.
Commit with a message like: “My Star Tic-Tac-Toe project”.
Push to your repository:git push origin main


Create a pull request to the course repository if required.
Include the compiled tictactoe (or tictactoe.exe) in the folder.

🚀 Future Enhancements
Here are some ideas I might try later:

Bigger board sizes (e.g., 5x5).
Harder math questions (like multiplication).
A computer player to play alone.
Saving scores to a file.
A graphical version with colors and buttons.

📜 License
This is my school project for educational use. Please don’t copy it, as I worked hard to make it unique! Feel free to use it for learning or personal fun.
🙏 Acknowledgments

Thanks to my teacher for teaching me C++!
I looked at C++ docs and Tic-Tac-Toe on Wikipedia for ideas.

Enjoy playing my Star Tic-Tac-Toe! ⭐
