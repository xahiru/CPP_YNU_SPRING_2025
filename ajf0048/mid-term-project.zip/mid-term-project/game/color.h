// colors.h - ANSI color definitions for terminal output

#ifndef COLORS_H
#define COLORS_H

#include <string>
#include <cstdlib>

namespace Color {
    // ANSI color escape codes
    const std::string RESET   = "\033[0m";
    const std::string BLACK   = "\033[30m";
    const std::string RED     = "\033[31m";
    const std::string GREEN   = "\033[32m";
    const std::string YELLOW  = "\033[33m";
    const std::string BLUE    = "\033[34m";
    const std::string MAGENTA = "\033[35m";
    const std::string CYAN    = "\033[36m";
    const std::string WHITE   = "\033[37m";
    
    // Text styles
    const std::string BOLD    = "\033[1m";
    const std::string UNDERLINE = "\033[4m";
    
    // Background colors
    const std::string BG_BLACK   = "\033[40m";
    const std::string BG_RED     = "\033[41m";
    const std::string BG_GREEN   = "\033[42m";
    const std::string BG_YELLOW  = "\033[43m";
    const std::string BG_BLUE    = "\033[44m";
    const std::string BG_MAGENTA = "\033[45m";
    const std::string BG_CYAN    = "\033[46m";
    const std::string BG_WHITE   = "\033[47m";
    
    // Function to check if terminal supports colors
    inline bool supportsColors() {
        const char* term = std::getenv("TERM");
        return term != nullptr && std::string(term) != "dumb";
    }
}

#endif // COLORS_H