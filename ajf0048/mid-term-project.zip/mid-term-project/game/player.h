#ifndef PLAYER_H
#define PLAYER_H

/**
 * @class Player
 * @brief Represents a player in the Tic-Tac-Toe game
 * 
 * This class manages player information including their symbol ('X' or 'O')
 * and tracks their score across multiple rounds.
 */
class Player {
private:
    char symbol; ///< Player's symbol (usually 'X' or 'O')
    int score;   ///< Player's current score (rounds won)

public:
    /**
     * @brief Constructor initializes player with a symbol
     * @param playerSymbol The character representing this player ('X' or 'O')
     */
    Player(char playerSymbol);
    
    /**
     * @brief Get the player's symbol
     * @return Character representing the player
     */
    char getSymbol() const;
    
    /**
     * @brief Get the player's current score
     * @return Number of rounds won by this player
     */
    int getScore() const;
    
    /**
     * @brief Increment player's score after winning a round
     */
    void incrementScore();
    
    /**
     * @brief Reset player's score to zero
     */
    void resetScore();
};

#endif // PLAYER_H