#include "player.h"

// Constructor
Player::Player(char playerSymbol) : symbol(playerSymbol), score(0) {}

// Get player's symbol (X or O)
char Player::getSymbol() const {
    return symbol;
}

// Get player's score
int Player::getScore() const {
    return score;
}

// Increment player's score after winning a round
void Player::incrementScore() {
    score++;
}

// Reset player's score
void Player::resetScore() {
    score = 0;
}