#include "game.h"
#include <iostream>
#include <sstream>

// Constructor with color option
Game::Game(bool useColors) : playerX('X'), playerO('O'), currentPlayer(&playerX), quiz(), ui(useColors), gamesPlayed(0) {
}

// Toggle color mode
void Game::toggleColors() {
    ui.toggleColor();
}

// Switch to the other player
void Game::switchPlayer() {
    currentPlayer = (currentPlayer == &playerX) ? &playerO : &playerX;
}

// Play a single round of the game
bool Game::playRound() {
    errorLog.clear();
    int boardSize = ui.getBoardSize();
    
    // Create the board
    Board gameBoard(boardSize);
    bool gameWon = false;
    
    // Game loop for a single round
    while (!gameWon && !gameBoard.isFull()) {
        ui.clearScreen();
        ui.displayBoard(gameBoard);
        
        std::cout << "Player " << currentPlayer->getSymbol() 
                 << "'s turn (u to undo, h for history, c to toggle colors): ";
        
        // Quiz question
        if (!ui.askQuizQuestion()) {
            std::cout << "Incorrect answer! Turn skipped.\n";
            std::cout << "Press Enter to continue...";
            std::cin.ignore();
            std::cin.get();
            switchPlayer();
            continue;
        }
        
        char action = ui.getCommand();
        
        if (action == 'u' || action == 'U') {
            if (gameBoard.undoLastMove()) {
                switchPlayer();
                std::cout << "Move undone.\n";
            } else {
                std::cout << "No moves to undo!\n";
            }
            std::cout << "Press Enter to continue...";
            std::cin.ignore();
            std::cin.get();
            continue;
        } 
        else if (action == 'h' || action == 'H') {
            ui.displayMoveHistory(gameBoard.getMoveHistory());
            std::cout << "Press Enter to continue...";
            std::cin.ignore();
            std::cin.get();
            continue;
        }
        else if (action == 'c' || action == 'C') {
            ui.toggleColor();
            continue;
        }
        else {
            std::cin.putback(action); // Put back non-action input
        }
        
        // Get and validate move
        int row, col;
        if (ui.getMove(row, col)) {
            if (gameBoard.placeSymbol(row, col, currentPlayer->getSymbol())) {
                if (gameBoard.checkWin(currentPlayer->getSymbol())) {
                    ui.clearScreen();
                    ui.displayBoard(gameBoard);
                    ui.displayWinner(currentPlayer->getSymbol());
                    currentPlayer->incrementScore();
                    gamesPlayed++;
                    gameWon = true;
                }
                switchPlayer();
            } else {
                std::stringstream ss;
                ss << "Invalid move (row: " << row + 1 << ", col: " << col + 1 
                   << ") by Player " << currentPlayer->getSymbol();
                errorLog.push_back(ss.str());
                std::cout << "Invalid move! Try again.\n";
                std::cout << "Press Enter to continue...";
                std::cin.get();
            }
        }
    }
    
    // Handle draw
    if (!gameWon && gameBoard.isFull()) {
        ui.clearScreen();
        ui.displayBoard(gameBoard);
        ui.displayWinner('D'); // 'D' for Draw
        gamesPlayed++;
    }
    
    // Display scoreboard
    ui.displayScore(playerX.getScore(), playerO.getScore(), gamesPlayed);
    
    // Check for overall winner (first to 3 wins)
    if (playerX.getScore() >= 3 || playerO.getScore() >= 3) {
        std::cout << "\nGame Over! Player " 
                 << (playerX.getScore() >= 3 ? 'X' : 'O') 
                 << " wins the match!\n";
        return false; // End the game
    }
    
    // Ask to play another round
    return ui.getPlayAgainChoice();
}

// Display final results and error log
void Game::displayFinalResults() {
    // Display error log for debugging
    if (!errorLog.empty()) {
        std::cout << "\nInput Error Log:\n";
        for (const auto& error : errorLog) {
            std::cout << error << "\n";
        }
    }
    
    std::cout << "Thanks for playing!\n";
}

// Start the game
void Game::start() {
    ui.displayInstructions();
    
    bool continuePlaying = true;
    while (continuePlaying) {
        continuePlaying = playRound();
    }
    
    displayFinalResults();
}