#include "board.h"
#include <vector>

// Constructor - initialize the board with given size
Board::Board(int boardSize) : size(boardSize) {
    // Allocate memory for the board
    grid = new char*[size];
    for (int i = 0; i < size; i++) {
        grid[i] = new char[size];
    }
    initialize();
}

// Destructor - clean up memory
Board::~Board() {
    for (int i = 0; i < size; i++) {
        delete[] grid[i];
    }
    delete[] grid;
}

// Initialize board with empty spaces
void Board::initialize() {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            grid[i][j] = ' ';
        }
    }
    moveHistory.clear();
}

// Get the value at a specific cell
char Board::getCell(int row, int col) const {
    if (row >= 0 && row < size && col >= 0 && col < size) {
        return grid[row][col];
    }
    return ' '; // Return space for invalid coordinates
}

// Place a symbol on the board
bool Board::placeSymbol(int row, int col, char symbol) {
    if (row < 0 || row >= size || col < 0 || col >= size || grid[row][col] != ' ') {
        return false; // Invalid move
    }
    
    grid[row][col] = symbol;
    addMoveToHistory(row, col, symbol);
    return true;
}

// Undo the last move
bool Board::undoLastMove() {
    if (moveHistory.empty()) {
        return false;
    }
    
    Move lastMove = moveHistory.back();
    grid[lastMove.row][lastMove.col] = ' ';
    moveHistory.pop_back();
    return true;
}

// Check if the board is full (for draw detection)
bool Board::isFull() const {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            if (grid[i][j] == ' ') {
                return false;
            }
        }
    }
    return true;
}

// Get board size
int Board::getSize() const {
    return size;
}

// Get move history
const std::vector<Move>& Board::getMoveHistory() const {
    return moveHistory;
}

// Add a move to history
void Board::addMoveToHistory(int row, int col, char player) {
    moveHistory.push_back({row, col, player});
}

// Check if a player has won
bool Board::checkWin(char player) const {
    int winLength = (size == 3) ? 3 : 4;
    
    // Check rows
    for (int i = 0; i < size; i++) {
        for (int j = 0; j <= size - winLength; j++) {
            bool win = true;
            for (int k = 0; k < winLength; k++) {
                if (grid[i][j + k] != player) {
                    win = false;
                    break;
                }
            }
            if (win) return true;
        }
    }
    
    // Check columns
    for (int j = 0; j < size; j++) {
        for (int i = 0; i <= size - winLength; i++) {
            bool win = true;
            for (int k = 0; k < winLength; k++) {
                if (grid[i + k][j] != player) {
                    win = false;
                    break;
                }
            }
            if (win) return true;
        }
    }
    
    // Check main diagonals (top-left to bottom-right)
    for (int i = 0; i <= size - winLength; i++) {
        for (int j = 0; j <= size - winLength; j++) {
            bool win = true;
            for (int k = 0; k < winLength; k++) {
                if (grid[i + k][j + k] != player) {
                    win = false;
                    break;
                }
            }
            if (win) return true;
        }
    }
    
    // Check anti-diagonals (top-right to bottom-left)
    for (int i = 0; i <= size - winLength; i++) {
        for (int j = winLength - 1; j < size; j++) {
            bool win = true;
            for (int k = 0; k < winLength; k++) {
                if (grid[i + k][j - k] != player) {
                    win = false;
                    break;
                }
            }
            if (win) return true;
        }
    }
    
    return false;
}