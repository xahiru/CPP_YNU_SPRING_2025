#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>
#include <cstdlib>
#include <ctime>

using namespace std;

// Cross-platform console clearing
#ifdef _WIN32
#define CLEAR "cls"
#else
#define CLEAR "clear"
#endif

// Structure to store a move for history and undo
struct Move {
    int row, col;
    char player;
};

// Function prototypes
void clearScreen();
void displayInstructions();
int getBoardSize();
void initializeBoard(char** board, int size);
void displayBoard(char** board, int size);
bool playerMove(char** board, int size, char player, vector<Move>& history, vector<string>& errorLog);
bool askQuizQuestion();
bool checkWin(char** board, int size, char player);
bool checkDraw(char** board, int size);
bool checkGameStatus(char** board, int size, char player, bool& gameWon);
void displayScore(int scoreX, int scoreO, int gamesPlayed);
void displayMoveHistory(const vector<Move>& history);
bool undoMove(char** board, vector<Move>& history);

// Main game function
int main() {
    srand(time(0)); // Seed random number generator
    vector<Move> moveHistory;
    vector<string> errorLog;
    int scoreX = 0, scoreO = 0, gamesPlayed = 0;
    char playAgain;

    displayInstructions();

    do {
        moveHistory.clear();
        errorLog.clear();
        int boardSize = getBoardSize();

        // Dynamically allocate board
        char** board = new char*[boardSize];
        for (int i = 0; i < boardSize; i++) {
            board[i] = new char[boardSize];
        }

        initializeBoard(board, boardSize);
        char currentPlayer = 'X';
        bool gameWon = false;

        // Game loop
        while (!gameWon && !checkDraw(board, boardSize)) {
            clearScreen();
            displayBoard(board, boardSize);
            cout << "Player " << currentPlayer << "'s turn (u to undo, h for history): ";

            // Quiz question
            if (!askQuizQuestion()) {
                cout << "Incorrect answer! Turn skipped.\n";
                cout << "Press Enter to continue...";
                cin.ignore();
                cin.get();
                currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
                continue;
            }

            char action;
            cin >> action;

            if (action == 'u' || action == 'U') {
                if (undoMove(board, moveHistory)) {
                    currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
                    cout << "Move undone.\n";
                } else {
                    cout << "No moves to undo!\n";
                }
                cout << "Press Enter to continue...";
                cin.ignore();
                cin.get();
                continue;
            } else if (action == 'h' || action == 'H') {
                displayMoveHistory(moveHistory);
                cout << "Press Enter to continue...";
                cin.ignore();
                cin.get();
                continue;
            } else {
                cin.putback(action); // Put back non-action input
            }

            if (playerMove(board, boardSize, currentPlayer, moveHistory, errorLog)) {
                if (checkGameStatus(board, boardSize, currentPlayer, gameWon)) {
                    clearScreen();
                    displayBoard(board, boardSize);
                    cout << "Player " << currentPlayer << " wins this round!\n";
                    if (currentPlayer == 'X') scoreX++;
                    else scoreO++;
                    gamesPlayed++;
                }
                currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
            }
        }

        // Handle draw
        if (!gameWon && checkDraw(board, boardSize)) {
            clearScreen();
            displayBoard(board, boardSize);
            cout << "It's a draw!\n";
            gamesPlayed++;
        }

        // Display scoreboard
        displayScore(scoreX, scoreO, gamesPlayed);

        // Check for overall winner (first to 3 wins)
        if (scoreX >= 3 || scoreO >= 3) {
            cout << "\nGame Over! Player " << (scoreX >= 3 ? 'X' : 'O') << " wins the match!\n";
            for (int i = 0; i < boardSize; i++) {
                delete[] board[i];
            }
            delete[] board;
            break;
        }

        // Clean up board memory
        for (int i = 0; i < boardSize; i++) {
            delete[] board[i];
        }
        delete[] board;

        // Play again?
        cout << "Play another round? (y/n): ";
        cin >> playAgain;
    } while (playAgain == 'y' || playAgain == 'Y');

    // Display error log for debugging
    if (!errorLog.empty()) {
        cout << "\nInput Error Log:\n";
        for (const auto& error : errorLog) {
            cout << error << "\n";
        }
    }

    cout << "Thanks for playing!\n";
    return 0;
}

// Clear the console screen (cross-platform)
void clearScreen() {
    system(CLEAR);
}

// Display game instructions
void displayInstructions() {
    clearScreen();
    cout << "Welcome to Enhanced Tic-Tac-Toe!\n\n";
    cout << "Instructions:\n";
    cout << "- Choose a board size (3 for 3x3, 4 for 4x4).\n";
    cout << "- Players take turns placing 'X' or 'O' on the grid.\n";
    cout << "- Before each move, answer a simple math question correctly.\n";
    cout << "- Enter row and column to make a move.\n";
    cout << "- Win a round by getting 3 in a row, column, or diagonal (4 for 4x4).\n";
    cout << "- First player to win 3 rounds wins the match.\n";
    cout << "- Type 'u' to undo a move, 'h' to see move history.\n";
    cout << "- If the board is full, it's a draw.\n\n";
    cout << "Press Enter to start...";
    cin.get();
}

// Get board size from user
int getBoardSize() {
    int size;
    do {
        cout << "Enter board size (3 or 4): ";
        cin >> size;
        if (size != 3 && size != 4) {
            cout << "Invalid size! Choose 3 or 4.\n";
        }
    } while (size != 3 && size != 4);
    return size;
}

// Initialize the board with empty spaces
void initializeBoard(char** board, int size) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            board[i][j] = ' ';
        }
    }
}

// Display the current board
void displayBoard(char** board, int size) {
    cout << "\n ";
    for (int j = 0; j < size; j++) {
        cout << " " << j + 1;
    }
    cout << "\n";
    for (int i = 0; i < size; i++) {
        cout << i + 1 << " ";
        for (int j = 0; j < size; j++) {
            cout << board[i][j];
            if (j < size - 1) cout << "|";
        }
        cout << "\n";
        if (i < size - 1) {
            cout << "  ";
            for (int j = 0; j < size - 1; j++) {
                cout << "-+";
            }
            cout << "-\n";
        }
    }
    cout << "\n";
}

// Handle player move with input validation
bool playerMove(char** board, int size, char player, vector<Move>& history, vector<string>& errorLog) {
    int row, col;
    cout << "Enter row (1-" << size << "): ";
    if (!(cin >> row)) {
        cin.clear();
        cin.ignore(10000, '\n');
        stringstream ss;
        ss << "Non-numeric row input by Player " << player;
        errorLog.push_back(ss.str());
        cout << "Invalid input! Try again.\n";
        cout << "Press Enter to continue...";
        cin.get();
        return false;
    }
    cout << "Enter column (1-" << size << "): ";
    if (!(cin >> col)) {
        cin.clear();
        cin.ignore(10000, '\n');
        stringstream ss;
        ss << "Non-numeric column input by Player " << player;
        errorLog.push_back(ss.str());
        cout << "Invalid input! Try again.\n";
        cout << "Press Enter to continue...";
        cin.get();
        return false;
    }

    // Convert to 0-based indexing
    row--;
    col--;

    // Validate input
    if (row < 0 || row >= size || col < 0 || col >= size || board[row][col] != ' ') {
        stringstream ss;
        ss << "Invalid move (row: " << row + 1 << ", col: " << col + 1 << ") by Player " << player;
        errorLog.push_back(ss.str());
        cout << "Invalid move! Try again.\n";
        cout << "Press Enter to continue...";
        cin.get();
        return false;
    }

    board[row][col] = player;
    history.push_back({row, col, player});
    return true;
}

// Generate and check a quiz question
bool askQuizQuestion() {
    int a = rand() % 20 + 1;
    int b = rand() % 20 + 1;
    char op = (rand() % 2 == 0) ? '+' : '-';
    int correctAnswer = (op == '+') ? (a + b) : (a - b);
    int userAnswer;

    cout << "Quiz: What is " << a << " " << op << " " << b << "? ";
    cin >> userAnswer;
    return userAnswer == correctAnswer;
}

// Check if the player has won
bool checkWin(char** board, int size, char player) {
    int winLength = (size == 3) ? 3 : 4;

    // Check rows
    for (int i = 0; i < size; i++) {
        for (int j = 0; j <= size - winLength; j++) {
            bool win = true;
            for (int k = 0; k < winLength; k++) {
                if (board[i][j + k] != player) {
                    win = false;
                    break;
                }
            }
            if (win) return true;
        }
    }

    // Check columns
    for (int j = 0; j < size; j++) {
        for (int i = 0; i <= size - winLength; i++) {
            bool win = true;
            for (int k = 0; k < winLength; k++) {
                if (board[i + k][j] != player) {
                    win = false;
                    break;
                }
            }
            if (win) return true;
        }
    }

    // Check main diagonals (top-left to bottom-right)
    for (int i = 0; i <= size - winLength; i++) {
        for (int j = 0; j <= size - winLength; j++) {
            bool win = true;
            for (int k = 0; k < winLength; k++) {
                if (board[i + k][j + k] != player) {
                    win = false;
                    break;
                }
            }
            if (win) return true;
        }
    }

    // Check anti-diagonals (top-right to bottom-left)
    for (int i = 0; i <= size - winLength; i++) {
        for (int j = winLength - 1; j < size; j++) {
            bool win = true;
            for (int k = 0; k < winLength; k++) {
                if (board[i + k][j - k] != player) {
                    win = false;
                    break;
                }
            }
            if (win) return true;
        }
    }

    return false;
}

// Check if the board is full (draw)
bool checkDraw(char** board, int size) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            if (board[i][j] == ' ') return false;
        }
    }
    return true;
}

// Check game status (win or draw)
bool checkGameStatus(char** board, int size, char player, bool& gameWon) {
    if (checkWin(board, size, player)) {
        gameWon = true;
        return true;
    }
    return false;
}

// Display the scoreboard
void displayScore(int scoreX, int scoreO, int gamesPlayed) {
    cout << "\nScoreboard:\n";
    cout << "Games Played: " << gamesPlayed << "\n";
    cout << "Player X Wins: " << scoreX << "\n";
    cout << "Player O Wins: " << scoreO << "\n";
    if (gamesPlayed > 0) {
        cout << "Player X Win %: " << fixed << setprecision(2)
             << (scoreX * 100.0 / gamesPlayed) << "%\n";
        cout << "Player O Win %: " << (scoreO * 100.0 / gamesPlayed) << "%\n";
    }
    cout << "\n";
}

// Display move history
void displayMoveHistory(const vector<Move>& history) {
    cout << "\nMove History:\n";
    if (history.empty()) {
        cout << "No moves yet.\n";
    } else {
        for (size_t i = 0; i < history.size(); i++) {
            cout << i + 1 << ". Player " << history[i].player
                 << " at (row: " << history[i].row + 1
                 << ", col: " << history[i].col + 1 << ")\n";
        }
    }
}

// Undo the last move
bool undoMove(char** board, vector<Move>& history) {
    if (history.empty()) return false;
    Move lastMove = history.back();
    board[lastMove.row][lastMove.col] = ' ';
    history.pop_back();
    return true;
}