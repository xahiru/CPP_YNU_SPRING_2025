/**
 * @file main_tictactoe.cpp
 * @brief Main entry point for the Tic-Tac-Toe game
 * 
 * This file contains the main function that initializes the game environment,
 * creates the Game instance, and starts the game loop. It serves as the entry
 * point for the entire application.
 */

 #include "game.h"
 #include "color.h"
 #include <iostream>
 #include <cstdlib>
 #include <ctime>
 
 /**
  * @brief Entry point for the Tic-Tac-Toe application
  * 
  * This function:
  * 1. Seeds the random number generator for quiz questions
  * 2. Creates a Game instance with color support enabled
  * 3. Starts the main game loop
  * 
  * @return 0 on successful execution
  */
 int main() {
     // Display welcome banner
     std::cout << "=================================================" << std::endl;
     std::cout << "          ENHANCED TIC-TAC-TOE GAME" << std::endl;
     std::cout << "=================================================" << std::endl;
     std::cout << "A C++ implementation with color support, quizzes," << std::endl;
     std::cout << "variable board size, and multi-round scoring." << std::endl;
     std::cout << "=================================================" << std::endl << std::endl;
 
     // Check for color support
     bool useColors = Color::supportsColors();
     if (!useColors) {
         std::cout << "Note: Your terminal may not support colors." << std::endl;
         std::cout << "Colors will be disabled by default, but you can" << std::endl;
         std::cout << "try enabling them with the 'c' command in-game." << std::endl << std::endl;
     }
 
     // Seed random number generator for quiz questions and other random elements
     std::srand(static_cast<unsigned int>(std::time(nullptr)));
     
     try {
         // Create the game instance with initial color setting
         Game tictactoe(useColors);
         
         // Start the main game loop
         tictactoe.start();
     } 
     catch (const std::exception& e) {
         // Handle any unexpected exceptions
         std::cerr << "Error: " << e.what() << std::endl;
         return 1;
     }
     
     // Display exit message
     std::cout << "Thanks for playing! Goodbye." << std::endl;
     
     return 0;
 }