#ifndef GAME_H
#define GAME_H

#include "board.h"
#include "player.h"
#include "quiz.h"
#include "ui.h"
#include <vector>
#include <string>

/**
 * @class Game
 * @brief Main game controller class for the Tic-Tac-Toe game
 * 
 * This class manages the entire game flow, including player turns,
 * multiple rounds, score tracking, and game completion.
 */
class Game {
private:
    Player playerX;          ///< Player using 'X' symbol
    Player playerO;          ///< Player using 'O' symbol
    Player* currentPlayer;   ///< Pointer to current active player
    Quiz quiz;               ///< Quiz component for educational gameplay
    UI ui;                   ///< User interface handler with color support
    std::vector<std::string> errorLog;  ///< Log of input and game errors
    int gamesPlayed;         ///< Counter for completed rounds
    
    /**
     * @brief Switches active player between X and O
     */
    void switchPlayer();
    
    /**
     * @brief Executes a single round of the game
     * @return true if another round should be played, false to end game
     */
    bool playRound();
    
    /**
     * @brief Displays final game results and error log
     */
    void displayFinalResults();
    
public:
    /**
     * @brief Constructor with color option
     * @param useColors Whether to enable colored output (default: true)
     */
    Game(bool useColors = true);
    
    /**
     * @brief Starts the main game loop
     */
    void start();
    
    /**
     * @brief Toggles color mode on/off during gameplay
     */
    void toggleColors();
};

#endif // GAME_H