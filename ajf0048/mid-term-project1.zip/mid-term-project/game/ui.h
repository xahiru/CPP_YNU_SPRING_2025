#ifndef TICTACTOE_UI_H
#define TICTACTOE_UI_H

#include <vector>
#include <string>

// Forward declarations
class Board;
struct Move;

/**
 * @class UI
 * @brief User interface manager for the TicTacToe game
 * 
 * This class handles all user interaction, display formatting,
 * color output, input validation, and visual presentation of the game.
 */
class UI {
private:
    bool colorEnabled; ///< Flag to enable/disable colored output

public:
    /**
     * @brief Constructor with color mode option
     * @param useColor Whether to enable colored output (default: true)
     */
    UI(bool useColor = true);

    /**
     * @brief Clears the console screen
     */
    void clearScreen() const;

    /**
     * @brief Toggles color mode on/off
     */
    void toggleColor();

    /**
     * @brief Checks if color mode is enabled
     * @return True if colors are enabled, false otherwise
     */
    bool isColorEnabled() const;

    /**
     * @brief Displays game instructions to the player
     */
    void displayInstructions() const;

    /**
     * @brief Renders the game board with proper formatting
     * @param board The game board to display
     */
    void displayBoard(const Board& board) const;

    /**
     * @brief Shows the current score between players
     * @param scoreX Number of rounds won by Player X
     * @param scoreO Number of rounds won by Player O
     * @param gamesPlayed Total number of rounds completed
     */
    void displayScore(int scoreX, int scoreO, int gamesPlayed) const;

    /**
     * @brief Displays the complete history of moves made
     * @param history Vector containing all moves in sequence
     */
    void displayMoveHistory(const std::vector<Move>& history) const;

    /**
     * @brief Announces the winner of a round
     * @param winner Character representing winner ('X', 'O', or 'D' for draw)
     */
    void displayWinner(char winner) const;

    /**
     * @brief Gets and validates board size selection from user
     * @return Selected board size (3 or 4)
     */
    int getBoardSize() const;

    /**
     * @brief Gets row and column input for a move
     * @param row Reference to store selected row (0-based)
     * @param col Reference to store selected column (0-based)
     * @return True if input was valid, false otherwise
     */
    bool getMove(int& row, int& col) const;

    /**
     * @brief Presents a math quiz question and checks answer
     * @return True if answered correctly, false otherwise
     */
    bool askQuizQuestion() const;

    /**
     * @brief Asks if player wants to play another round
     * @return True to play again, false to end game
     */
    bool getPlayAgainChoice() const;

    /**
     * @brief Gets a command input for special actions
     * @return Character representing the command ('u', 'h', 'c', etc.)
     */
    char getCommand() const;
};

#endif // TICTACTOE_UI_H