#include "quiz.h"
#include <iostream>
#include <cstdlib>
#include <ctime>

// Constructor
Quiz::Quiz() {
    // Note: Random seed is set in main.cpp
}

// Generate a random number within range
int Quiz::generateNumber(int min, int max) {
    return min + (std::rand() % (max - min + 1));
}

// Select a random question type
Quiz::QuestionType Quiz::selectRandomType() {
    int type = std::rand() % 3;
    return static_cast<QuestionType>(type);
}

// Ask a quiz question - return true if answered correctly
bool Quiz::askQuestion() {
    int a = generateNumber(1, 20);
    int b = generateNumber(1, 20);
    int correctAnswer = 0;
    char op;
    
    // Select question type and calculate answer
    QuestionType type = selectRandomType();
    switch (type) {
        case ADDITION:
            op = '+';
            correctAnswer = a + b;
            break;
        case SUBTRACTION:
            op = '-';
            correctAnswer = a - b;
            break;
        case MULTIPLICATION:
            op = '*';
            // Use smaller numbers for multiplication
            a = generateNumber(1, 10);
            b = generateNumber(1, 10);
            correctAnswer = a * b;
            break;
    }
    
    // Ask the question and get answer
    int userAnswer;
    std::cout << "Quiz: What is " << a << " " << op << " " << b << "? ";
    
    // Handle invalid input
    if (!(std::cin >> userAnswer)) {
        std::cin.clear();
        std::cin.ignore(10000, '\n');
        std::cout << "Invalid input! That's not a number.\n";
        return false;
    }
    
    return userAnswer == correctAnswer;
}