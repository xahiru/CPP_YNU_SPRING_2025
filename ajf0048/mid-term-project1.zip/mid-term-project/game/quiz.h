#ifndef QUIZ_H
#define QUIZ_H

#include <string>

/**
 * @class Quiz
 * @brief Educational component for the Tic-Tac-Toe game
 * 
 * This class generates and validates math questions that players
 * must answer correctly before making a move, adding an educational
 * element to the gameplay.
 */
class Quiz {
private:
    /**
     * @enum QuestionType
     * @brief Types of math questions that can be generated
     */
    enum QuestionType {
        ADDITION,       ///< Addition problems (a + b)
        SUBTRACTION,    ///< Subtraction problems (a - b)
        MULTIPLICATION  ///< Multiplication problems (a * b)
    };
    
    /**
     * @brief Generate a random number within a specified range
     * @param min Lower bound (inclusive)
     * @param max Upper bound (inclusive)
     * @return Random number between min and max
     */
    int generateNumber(int min, int max);
    
    /**
     * @brief Select a random question type
     * @return QuestionType enum value representing the chosen type
     */
    QuestionType selectRandomType();
    
public:
    /**
     * @brief Constructor - initializes quiz generator
     */
    Quiz();
    
    /**
     * @brief Generate, display, and validate a quiz question
     * 
     * Generates a random math question, presents it to the user,
     * gets their answer, and checks if it's correct.
     * 
     * @return True if the answer was correct, false otherwise
     */
    bool askQuestion();
};

#endif // QUIZ_H