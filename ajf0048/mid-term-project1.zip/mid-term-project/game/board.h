#ifndef BOARD_H
#define BOARD_H

#include <vector>
#include <string>

/**
 * @struct Move
 * @brief Structure to store a move for history and undo functionality
 */
struct Move {
    int row;     ///< Row position (0-based index)
    int col;     ///< Column position (0-based index)
    char player; ///< Symbol of player who made the move ('X' or 'O')
};

/**
 * @class Board
 * @brief Manages the Tic-Tac-Toe game board state and operations
 * 
 * This class handles the game board representation, move validation,
 * history tracking, win detection, and board state management.
 */
class Board {
private:
    int size;                       ///< Board dimensions (3x3 or 4x4)
    char** grid;                    ///< 2D array to store the board state
    std::vector<Move> moveHistory;  ///< History of all moves made

public:
    /**
     * @brief Constructor - allocates and initializes the board
     * @param boardSize Dimensions of the board (3 or 4)
     */
    Board(int boardSize);
    
    /**
     * @brief Destructor - properly frees allocated memory
     */
    ~Board();

    /**
     * @brief Reset board to empty state
     */
    void initialize();
    
    /**
     * @brief Get symbol at specified position
     * @param row Row position (0-based)
     * @param col Column position (0-based)
     * @return Character at position (' ', 'X', or 'O')
     */
    char getCell(int row, int col) const;
    
    /**
     * @brief Place a symbol on the board
     * @param row Row position (0-based)
     * @param col Column position (0-based)
     * @param symbol Symbol to place ('X' or 'O')
     * @return True if move was valid and placed, false otherwise
     */
    bool placeSymbol(int row, int col, char symbol);
    
    /**
     * @brief Remove the last move from the board
     * @return True if a move was undone, false if history is empty
     */
    bool undoLastMove();
    
    /**
     * @brief Check if the board is completely filled
     * @return True if full (draw condition), false otherwise
     */
    bool isFull() const;
    
    /**
     * @brief Get the board dimensions
     * @return Size of the board (3 or 4)
     */
    int getSize() const;

    /**
     * @brief Get the complete move history
     * @return Reference to the vector of moves
     */
    const std::vector<Move>& getMoveHistory() const;
    
    /**
     * @brief Add a move to the history
     * @param row Row position (0-based)
     * @param col Column position (0-based)
     * @param player Symbol of player who made the move
     */
    void addMoveToHistory(int row, int col, char player);
    
    /**
     * @brief Check if a player has won
     * @param player The player symbol to check for win ('X' or 'O')
     * @return True if player has won, false otherwise
     */
    bool checkWin(char player) const;
};

#endif // BOARD_H