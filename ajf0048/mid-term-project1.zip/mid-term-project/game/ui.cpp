#include "ui.h"
#include "board.h"
#include "color.h"
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <ctime>

// Cross-platform screen clearing
#ifdef _WIN32
#define CLEAR "cls"
#else
#define CLEAR "clear"
#endif

// Constructor
UI::UI(bool useColor) : colorEnabled(useColor) {
}

// Toggle color mode
void UI::toggleColor() {
    colorEnabled = !colorEnabled;
    if (colorEnabled) {
        std::cout << Color::GREEN << "Color mode enabled!" << Color::RESET << std::endl;
    } else {
        std::cout << "Color mode disabled!" << std::endl;
    }
}

bool UI::isColorEnabled() const {
    return colorEnabled;
}

// Clear the console screen
void UI::clearScreen() const {
    system(CLEAR);
}

// Display game instructions
void UI::displayInstructions() const {
    clearScreen();
    if (colorEnabled) {
        std::cout << Color::CYAN << Color::BOLD << "Welcome to Enhanced Tic-Tac-Toe!" << Color::RESET << std::endl << std::endl;
        std::cout << Color::YELLOW << "Instructions:" << Color::RESET << std::endl;
        std::cout << "- Choose a board size (3 for 3x3, 4 for 4x4).\n";
        std::cout << "- Players take turns placing 'X' or 'O' on the grid.\n";
        std::cout << "- Before each move, answer a simple math question correctly.\n";
        std::cout << "- Enter row and column to make a move.\n";
        std::cout << "- Win a round by getting 3 in a row, column, or diagonal (4 for 4x4).\n";
        std::cout << "- First player to win 3 rounds wins the match.\n";
        std::cout << "- Type 'u' to undo a move, 'h' to see move history, 'c' to toggle colors.\n";
        std::cout << "- If the board is full, it's a draw.\n\n";
        std::cout << Color::GREEN << "Press Enter to start..." << Color::RESET;
    } else {
        std::cout << "Welcome to Enhanced Tic-Tac-Toe!\n\n";
        std::cout << "Instructions:\n";
        std::cout << "- Choose a board size (3 for 3x3, 4 for 4x4).\n";
        std::cout << "- Players take turns placing 'X' or 'O' on the grid.\n";
        std::cout << "- Before each move, answer a simple math question correctly.\n";
        std::cout << "- Enter row and column to make a move.\n";
        std::cout << "- Win a round by getting 3 in a row, column, or diagonal (4 for 4x4).\n";
        std::cout << "- First player to win 3 rounds wins the match.\n";
        std::cout << "- Type 'u' to undo a move, 'h' to see move history, 'c' to toggle colors.\n";
        std::cout << "- If the board is full, it's a draw.\n\n";
        std::cout << "Press Enter to start...";
    }
    std::cin.get();
}

// Display the game board
void UI::displayBoard(const Board& board) const {
    int size = board.getSize();
    
    if (colorEnabled) {
        std::cout << Color::CYAN << "\n ";
        for (int j = 0; j < size; j++) {
            std::cout << " " << j + 1;
        }
        std::cout << Color::RESET << "\n";
        
        for (int i = 0; i < size; i++) {
            std::cout << Color::CYAN << i + 1 << " " << Color::RESET;
            for (int j = 0; j < size; j++) {
                char cell = board.getCell(i, j);
                if (cell == 'X') {
                    std::cout << Color::BLUE << cell << Color::RESET;
                } else if (cell == 'O') {
                    std::cout << Color::RED << cell << Color::RESET;
                } else {
                    std::cout << cell;
                }
                
                if (j < size - 1) std::cout << Color::WHITE << "|" << Color::RESET;
            }
            std::cout << "\n";
            
            if (i < size - 1) {
                std::cout << "  ";
                for (int j = 0; j < size - 1; j++) {
                    std::cout << Color::WHITE << "-+" << Color::RESET;
                }
                std::cout << Color::WHITE << "-" << Color::RESET << "\n";
            }
        }
    } else {
        std::cout << "\n ";
        for (int j = 0; j < size; j++) {
            std::cout << " " << j + 1;
        }
        std::cout << "\n";
        
        for (int i = 0; i < size; i++) {
            std::cout << i + 1 << " ";
            for (int j = 0; j < size; j++) {
                std::cout << board.getCell(i, j);
                if (j < size - 1) std::cout << "|";
            }
            std::cout << "\n";
            
            if (i < size - 1) {
                std::cout << "  ";
                for (int j = 0; j < size - 1; j++) {
                    std::cout << "-+";
                }
                std::cout << "-\n";
            }
        }
    }
    std::cout << "\n";
}

// Display current score
void UI::displayScore(int scoreX, int scoreO, int gamesPlayed) const {
    if (colorEnabled) {
        std::cout << Color::YELLOW << "Score after " << gamesPlayed << " rounds: " << Color::RESET;
        std::cout << Color::BLUE << "X: " << scoreX << Color::RESET << " | ";
        std::cout << Color::RED << "O: " << scoreO << Color::RESET << std::endl;
    } else {
        std::cout << "Score after " << gamesPlayed << " rounds: ";
        std::cout << "X: " << scoreX << " | ";
        std::cout << "O: " << scoreO << std::endl;
    }
}

// Display move history
void UI::displayMoveHistory(const std::vector<Move>& history) const {
    if (history.empty()) {
        if (colorEnabled) {
            std::cout << Color::YELLOW << "No moves have been made yet." << Color::RESET << std::endl;
        } else {
            std::cout << "No moves have been made yet." << std::endl;
        }
        return;
    }
    
    if (colorEnabled) {
        std::cout << Color::YELLOW << "\nMove History:" << Color::RESET << std::endl;
        std::cout << "----------------" << std::endl;
        
        for (size_t i = 0; i < history.size(); ++i) {
            std::cout << "Move " << (i + 1) << ": Player ";
            
            if (history[i].player == 'X') {
                std::cout << Color::BLUE << 'X' << Color::RESET;
            } else {
                std::cout << Color::RED << 'O' << Color::RESET;
            }
            
            std::cout << " placed at row " << (history[i].row + 1) 
                     << ", column " << (history[i].col + 1) << std::endl;
        }
    } else {
        std::cout << "\nMove History:" << std::endl;
        std::cout << "----------------" << std::endl;
        
        for (size_t i = 0; i < history.size(); ++i) {
            std::cout << "Move " << (i + 1) << ": Player " << history[i].player
                     << " placed at row " << (history[i].row + 1) 
                     << ", column " << (history[i].col + 1) << std::endl;
        }
    }
}

// Display winner
void UI::displayWinner(char winner) const {
    if (winner == 'D') {
        if (colorEnabled) {
            std::cout << Color::YELLOW << "It's a draw!" << Color::RESET << std::endl;
        } else {
            std::cout << "It's a draw!" << std::endl;
        }
    } else {
        if (colorEnabled) {
            std::cout << Color::BOLD;
            if (winner == 'X') {
                std::cout << Color::BLUE << "Player X" << Color::RESET << Color::BOLD;
            } else {
                std::cout << Color::RED << "Player O" << Color::RESET << Color::BOLD;
            }
            std::cout << " wins this round!" << Color::RESET << std::endl;
        } else {
            std::cout << "Player " << winner << " wins this round!" << std::endl;
        }
    }
}

// Get board size from user
int UI::getBoardSize() const {
    int size;
    do {
        if (colorEnabled) {
            std::cout << Color::CYAN << "Enter board size (3 or 4): " << Color::RESET;
        } else {
            std::cout << "Enter board size (3 or 4): ";
        }
        
        // Handle non-numeric input
        if (!(std::cin >> size)) {
            std::cin.clear(); // Clear error flags
            std::cin.ignore(10000, '\n'); // Discard invalid input
            size = 0; // Set to invalid value to continue loop
            if (colorEnabled) {
                std::cout << Color::RED << "Please enter a number (3 or 4)." << Color::RESET << std::endl;
            } else {
                std::cout << "Please enter a number (3 or 4).\n";
            }
            continue;
        }
        
        if (size != 3 && size != 4) {
            if (colorEnabled) {
                std::cout << Color::RED << "Invalid size! Choose 3 or 4." << Color::RESET << std::endl;
            } else {
                std::cout << "Invalid size! Choose 3 or 4.\n";
            }
        }
    } while (size != 3 && size != 4);
    return size;
}

// Get player move
bool UI::getMove(int& row, int& col) const {
    if (colorEnabled) {
        std::cout << Color::CYAN << "Enter row (1-4): " << Color::RESET;
    } else {
        std::cout << "Enter row (1-4): ";
    }
    
    if (!(std::cin >> row)) {
        std::cin.clear();
        std::cin.ignore(10000, '\n');
        if (colorEnabled) {
            std::cout << Color::RED << "Invalid input! Try again." << Color::RESET << std::endl;
        } else {
            std::cout << "Invalid input! Try again.\n";
        }
        return false;
    }
    
    if (colorEnabled) {
        std::cout << Color::CYAN << "Enter column (1-4): " << Color::RESET;
    } else {
        std::cout << "Enter column (1-4): ";
    }
    
    if (!(std::cin >> col)) {
        std::cin.clear();
        std::cin.ignore(10000, '\n');
        if (colorEnabled) {
            std::cout << Color::RED << "Invalid input! Try again." << Color::RESET << std::endl;
        } else {
            std::cout << "Invalid input! Try again.\n";
        }
        return false;
    }
    
    // Convert to 0-based indexing
    row--;
    col--;
    
    return true;
}

// Generate and check a quiz question
bool UI::askQuizQuestion() const {
    int a = rand() % 20 + 1;
    int b = rand() % 20 + 1;
    char op = (rand() % 2 == 0) ? '+' : '-';
    int correctAnswer = (op == '+') ? (a + b) : (a - b);
    int userAnswer;

    if (colorEnabled) {
        std::cout << Color::YELLOW << "Quiz: What is " << a << " " << op << " " << b << "? " << Color::RESET;
    } else {
        std::cout << "Quiz: What is " << a << " " << op << " " << b << "? ";
    }
    
    // Handle non-numeric input
    if (!(std::cin >> userAnswer)) {
        std::cin.clear(); // Clear error flags
        std::cin.ignore(10000, '\n'); // Discard invalid input
        if (colorEnabled) {
            std::cout << Color::RED << "Invalid input! The correct answer was " << correctAnswer << "." << Color::RESET << std::endl;
        } else {
            std::cout << "Invalid input! The correct answer was " << correctAnswer << ".\n";
        }
        return false;
    }
    
    if (userAnswer == correctAnswer) {
        if (colorEnabled) {
            std::cout << Color::GREEN << "Correct!" << Color::RESET << std::endl;
        } else {
            std::cout << "Correct!\n";
        }
        return true;
    } else {
        if (colorEnabled) {
            std::cout << Color::RED << "Wrong! The correct answer was " << correctAnswer << "." << Color::RESET << std::endl;
        } else {
            std::cout << "Wrong! The correct answer was " << correctAnswer << ".\n";
        }
        return false;
    }
}

// Get play again choice
bool UI::getPlayAgainChoice() const {
    char choice;
    std::cout << "Play another round? (y/n): ";
    std::cin >> choice;
    return (choice == 'y' || choice == 'Y');
}

// Get command (for undo, history, etc.)
char UI::getCommand() const {
    char command;
    std::cin >> command;
    return command;
}