#ifndef PLAYER_H
#define PLAYER_H

class Player {
public:
    Player();
    void addWin();
    void addloss();
    void displayScore() const;
    void addPoints(int points);

private:
    int wins;
    int losses;
    int score = 0;
};

#endif