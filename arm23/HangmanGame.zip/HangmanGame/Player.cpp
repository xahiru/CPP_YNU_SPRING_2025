#include "Player.h"
#include <iostream>

Player::Player() : wins(0), losses(0) {}

void Player::addWin() {
    wins++;
}

void Player::addloss() {
    losses++;
}

void Player::displayScore() const {
    std::cout << "\n===== SCOREBOARD =====\n";
    std::cout << "Wins: " << wins << "\nLosses: " << losses << "\n";
}

void Player::addPoints(int points) {
    score += points;
}