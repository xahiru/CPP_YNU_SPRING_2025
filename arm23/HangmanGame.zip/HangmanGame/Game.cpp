#include "Game.h"
#include "Words.h"
#include <iostream>
#include <vector> 
#include <map> 
#include <algorithm> 
#include <cctype> 
#include <cstdlib> 
#include <ctime>

// ANSI Colors 
const std::string RED = "\033[31m"; 
const std::string GREEN = "\033[32m"; 
const std::string YELLOW = "\033[33m"; 
const std::string CYAN = "\033[36m"; 
const std::string RESET = "\033[0m";

Game::Game(Player& player) : playerRef(player) { 
    std::srand(static_cast<unsigned int>(std::time(nullptr))); 
}

void Game::displayInstructions() { 
    std::cout << CYAN; 
    std::cout << "==============================\n"; 
    std::cout << "      WELCOME TO HANGMAN      \n"; 
    std::cout << "==============================\n" << RESET; 
    std::cout << "Guess the word by entering one letter at a time.\n"; 
    std::cout << "You have " << YELLOW << "6 tries" << RESET << " before you lose.\n\n"; 
}

void Game::displayLives(int tries, int maxTries) {
    int livesLeft = maxTries - tries;
    std::cout << "\nLives left: " << livesLeft << "\n";
    displayHangman(livesLeft);
}

 void Game::displayHangman(int livesLeft) {
    switch (livesLeft) {
        case 6:
            std::cout << "  +---+\n"
                         "  |   |\n"
                         "      |\n"
                         "      |\n"
                         "      |\n"
                         "      |\n"
                         "=========\n";
            break;
        case 5:
            std::cout << "  +---+\n"
                         "  |   |\n"
                         "  O   |\n"
                         "      |\n"
                         "      |\n"
                         "      |\n"
                         "=========\n";
            break;
        case 4:
            std::cout << "  +---+\n"
                         "  |   |\n"
                         "  O   |\n"
                         "  |   |\n"
                         "      |\n"
                         "      |\n"
                         "=========\n";
            break;
        case 3:
            std::cout << "  +---+\n"
                         "  |   |\n"
                         "  O   |\n"
                         " /|   |\n"
                         "      |\n"
                         "      |\n"
                         "=========\n";
            break;
        case 2:
            std::cout << "  +---+\n"
                         "  |   |\n"
                         "  O   |\n"
                         " /|\\  |\n"
                         "      |\n"
                         "      |\n"
                         "=========\n";
            break;
        case 1:
            std::cout << "  +---+\n"
                         "  |   |\n"
                         "  O   |\n"
                         " /|\\  |\n"
                         " /    |\n"
                         "      |\n"
                         "=========\n";
            break;
        case 0:
            std::cout << "  +---+\n"
                         "  |   |\n"
                         "  O   |\n"
                         " /|\\  |\n"
                         " / \\  |\n"
                         "      |\n"
                         "=========\n";
            break;
    }
}

std::string Game::chooseCategory() { 
    std::vector<std::string> categories = getCategories(); 
    std::cout << GREEN << "Choose a category:\n" << RESET; 
    for (size_t i = 0; i < categories.size(); ++i) { 
        std::cout << i + 1 << ". " << categories[i] << '\n'; 
     }

 int choice; 
 std::cin >> choice; 
 while (choice < 1 || choice > (int)categories.size()) {
    std::cout << RED << "Invalid. Try again: " << RESET; 
    std::cin >> choice; 
 }

 return categories[choice - 1]; 
}

std::string Game::chooseWord(const std::string& category) { 
    return getRandomWordFromCategory(category);
 }

void Game::start() { 
    std::string category = chooseCategory(); 
    std::string word = chooseWord(category); 
    std::string display(word.length(), '_');
    std::vector<char> wrongGuesses; 
    int tries = 0, maxTries = 6;

while (display != word && tries < maxTries) {
  std::cout << "\nWord: " << display << "\n";
  std::cout << "Wrong guesses: ";
  for (char ch : wrongGuesses)
  std::cout << ch << ' ';
 displayLives(tries, maxTries);

    char guess; 
    std::cout << "Enter a letter: "; 
    std::cin >> guess;  
    guess = std::tolower(guess);

 if (word.find(guess) != std::string::npos) { 
    for (size_t i = 0; i < word.length(); ++i) 
    if (word[i] == guess) 
    display[i] = guess;  
std::cout << GREEN << "Correct!\n" << RESET; 
} else { 
    if (std::find(wrongGuesses.begin(), wrongGuesses.end(), guess) == wrongGuesses.end()) { 
        wrongGuesses.push_back(guess); 
        ++tries; 
        std::cout << RED << "Wrong!\n" << RESET;
    } else { 
         std::cout << YELLOW << "Already guessed.\n" << RESET;  
        } 
    } 
}

if (display == word) {
    std::cout << GREEN << "\nYou guessed it! The word was: " << word << "\n" << RESET;  
    playerRef.addWin();  
    std::string fact = getFunFact(word); 
    if (!fact.empty()) { 
        std::cout << CYAN << "Fun fact: " << fact << "\n" << RESET; 
    } 
 } else { 
    std::cout << RED << "\nYou lost! The word was: " << word << "\n" << RESET; 
    playerRef.addloss();
} 
}
