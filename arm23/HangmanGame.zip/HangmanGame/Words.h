#ifndef WORDS_H
#define WORDS_H

#include <vector>
#include <string>

std::vector<std::string> getCategories();
std::string getRandomWordFromCategory(const 
std::string& category);
std::string getFunFact(const std::string& word);

#endif 