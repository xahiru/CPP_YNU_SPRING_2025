#ifndef GAME_H
#define GAME_H

#include <string>
#include "Player.h"

class Game {
 public:
    Game(Player& player);
    void displayInstructions();
    void start();
    void displayLives(int tries, int maxTries);
    void displayHangman(int livesLeft);

private:
    std::string chooseCategory();
    std::string chooseWord(const std::string& category);
    Player& playerRef;
    std::string currentTheme;
};

#endif