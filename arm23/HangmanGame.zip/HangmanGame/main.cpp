#include "Game.h"
#include "Player.h"
#include <iostream>

// ANSI escape codes for colors
const std::string RED = "\033[31m";
const std::string GREEN = "\033[32m";
const std::string YELLOW = "\033[33m";
const std::string BLUE = "\033[34m";
const std::string MAGENTA = "\033[35m";
const std::string CYAN = "\033[36m";
const std::string RESET = "\033[0m";

// Cute colorful title
void printTitle() {
    std::cout << CYAN;
    std::cout << R"( 
  _   _                                              
 | | | |
 | |_| | __ _ _ __   __ _ _ __ ___   __ _ _ __
 |  _  |/ _` | '_ \ / _` | '_ ` _ \ / _` | '_ \
 | | | | (_| | | | | (_| | | | | | | (_| | | | |
 \_| |_/\__,_|_| |_|\__, |_| |_| |_|\__,_|_| |_|
                     __/ |
                    |___/        )" << std::endl;
    std::cout << RESET;
    std::cout << MAGENTA << "\n   Welcome to Hangman! Let's play and have fun!\n\n" << RESET;
}

int main() {
    printTitle();

    Player player;
    Game game(player);
    game.displayInstructions();

    char choice;
    do {
        game.start();
        std::cout << YELLOW << "Do you want to play again? (y/n): " << RESET;
        std::cin >> choice;
    } while (choice == 'y' || choice == 'Y');

    player.displayScore();
    std::cout << GREEN << "Thanks for playing Hangman! See you next time!" << RESET << std::endl;

    return 0;  
}