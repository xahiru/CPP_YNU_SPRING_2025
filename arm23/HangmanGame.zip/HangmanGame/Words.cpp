#include "Words.h"
#include <map>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <string>

std::vector<std::string> getCategories() {
  return {"Fruits", "Animals", "Countries"};
}

std::string getRandomWordFromCategory(const std::string& category) {
   std::map<std::string, std::vector<std::string>> wordBank = {
     {"Fruits", {"apple", "banana", "mango", "peach", "grape", "kiwi", "orange", "cherry"}},
      {"Animals", {"tiger", "zebra", "giraffe", "lion", "rabbit", "elephant", "koala", "panda"}},
     {"Countries", {"kenya", "brazil", "canada", "india", "japan", "norway", "france", "egypt"}}
 };

   srand((unsigned int)time(0));
   const std::vector<std::string>& words = wordBank[category];
   return words[rand() % words.size()];
}

std::string getFunFact(const std::string& word) {
   static std::map<std::string, std::string> funFacts = {

    {"apple", "Apples float in water because they are 25% air."},
    {"banana", "Bananas are berries, but strawberries aren't!"},
    {"mango", "Mangoes are known as the king of fruits in India."},
    {"peach", "Peaches are related to almonds."},
    {"grape", "Grapes explode when you microwave them (don't try it!)."},
    {"kiwi", "Kiwis contain more vitamin C than oranges."},
    {"orange", "Oranges are actually a hybrid fruit."},
    {"cherry", "Cherries are a member of the rose family."},

    {"zebra", "Zebras are actually black with white stripes."},
    {"lion", "A lion's roar can be heard from 8 km away."},
    {"tiger", "Tigers have striped skin, not just striped fur."},
    {"giraffe", "Giraffes have the same number of neck bones as humans."},
    {"rabbit", "Rabbits teeth never stop growing."},
    {"elephant", "Elephants are the only mammals that can't jump!"},
    {"koala", "Koalas sleep up to 22 hours a day."},
    {"panda", "Pandas eat for about 12 hours a day."},

    {"kenya", "Kenya is home to the Great Rift Valley."},
    {"brazil", "Brazil has won the most FIFA World Cups."},
    {"canada", "Canada has the longest coastline in the world."},
    {"india", "India is the world's largest democracy."},
    {"japan", "Japan has more than 6,800 islands."},
    {"norway", "Norway is called the Land of the Midnight Sun."},
    {"france", "France is the most visited country in the world."},
    {"egypt", "Ancient Egyptians invented the 365-day calendar."}
  };

  auto it = funFacts.find(word);
  if (it != funFacts.end()) {
    return it->second;
  }
  return "";
}