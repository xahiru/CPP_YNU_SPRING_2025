#ifndef PERSON_H
#define PERSON_H

#include <string>

class Person {
protected:
    std::string name, id;
    int age;

public:
    Person(std::string n = "", std::string i = "", int a = 0);
    virtual void display() const;
    std::string getId() const;
    virtual std::string getName() const;
    virtual int getAge() const;
    virtual ~Person();
};

#endif