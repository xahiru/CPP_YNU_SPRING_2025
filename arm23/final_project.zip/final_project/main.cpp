#include "student.h"
#include "faculty.h"
#include "course.h"
#include "file_utils.h"
#include <iostream>
#include <map>
#include <limits>
#include <stdexcept>
#include <algorithm>

using namespace std;

void displayMenu() {
    cout << "\n===== University Student Management System =====\n";
    cout << "1. Add Student\n";
    cout << "2. Add Faculty\n";
    cout << "3. Add Course\n";
    cout << "4. Enroll Student in Course\n";
    cout << "5. Assign Grade\n";
    cout << "6. Display Student Info\n";
    cout << "7. Display Course Info\n";
    cout << "8. Generate Student Transcript\n";
    cout << "9. Export Course Summaries\n";
    cout << "10. Find Top Performers\n";
    cout << "11. Search by Name\n";
    cout << "12. Filter Courses by Instructor\n";
    cout << "13. Undo Last Action\n";
    cout << "14. Save Students to File\n";
    cout << "0. Exit\n";
    cout << "Choose an option: ";
}

bool nameMatches(const string& name, const string& keyword) {
    return name.find(keyword) != string::npos;
}

int main() {
    map<string, Student*> students;
    map<string, Faculty*> faculty;
    map<string, Course*> courses;

    map<string, Student*> studentsBackup;
    map<string, Course*> coursesBackup;

    int choice;
    GPAScale gpaScale = SCALE_4;

    do {
        displayMenu();
        cin >> choice;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        try {
            if (choice == 1) {
                string name, id;
                int age;
                cout << "Enter student name, ID, and age: ";
                getline(cin, name); getline(cin, id); cin >> age; cin.ignore();
                Student* s = new Student(name, id, age);
                backupData(students, courses, studentsBackup, coursesBackup);
                students[id] = s;
            } else if (choice == 2) {
                string name, id, spec;
                int age;
                cout << "Enter faculty name, ID, age, specialization: ";
                getline(cin, name); getline(cin, id); cin >> age; cin.ignore(); getline(cin, spec);
                faculty[id] = new Faculty(name, id, age, spec);
            } else if (choice == 3) {
                string code, title, facId;
                cout << "Enter course code, title, and faculty ID: ";
                getline(cin, code); getline(cin, title); getline(cin, facId);
                if (!faculty.count(facId)) throw runtime_error("Faculty not found.");
                backupData(students, courses, studentsBackup, coursesBackup);
                courses[code] = new Course(code, title, faculty[facId]);
            } else if (choice == 4) {
                string studentId, courseCode;
                cout << "Enter student ID and course code: ";
                getline(cin, studentId); getline(cin, courseCode);
                if (!students.count(studentId) || !courses.count(courseCode))
                    throw runtime_error("Invalid student/course ID.");
                backupData(students, courses, studentsBackup, coursesBackup);
                courses[courseCode]->enrollStudent(students[studentId]);
            } else if (choice == 5) {
                string studentId, courseCode;
                char grade;
                cout << "Enter student ID, course code, and grade: ";
                getline(cin, studentId); getline(cin, courseCode); cin >> grade; cin.ignore();
                if (!students.count(studentId)) throw runtime_error("Student not found.");
                students[studentId]->addGrade(courseCode, grade);
            } else if (choice == 6) {
                string studentId;
                cout << "Enter student ID: ";
                getline(cin, studentId);
                if (!students.count(studentId)) throw runtime_error("Student not found.");
                students[studentId]->display();
            } else if (choice == 7) {
                string courseCode;
                cout << "Enter course code: ";
                getline(cin, courseCode);
                if (!courses.count(courseCode)) throw runtime_error("Course not found.");
                courses[courseCode]->displayCourse();
            } else if (choice == 8) {
                string studentId;
                cout << "Enter student ID for transcript: ";
                getline(cin, studentId);
                if (!students.count(studentId)) throw runtime_error("Student not found.");
                cout << "Use which GPA scale? (1 = 4.0, 2 = percentage): ";
                int scaleInput;
                cin >> scaleInput; cin.ignore();
                gpaScale = (scaleInput == 2) ? PERCENTAGE : SCALE_4;
                students[studentId]->generateTranscript(studentId + "_transcript.txt", gpaScale);
                cout << "Transcript saved as " << studentId << "_transcript.txt\n";
            } else if (choice == 9) {
                saveCourseSummaries(courses, "course_reports");
                cout << "Course summaries saved in folder: course_reports/\n";
            } else if (choice == 10) {
                float threshold;
                cout << "Enter GPA threshold: ";
                cin >> threshold; cin.ignore();
                cout << "Top Performers:\n";
                for (const auto& [id, s] : students) {
                    if (s->hasHighGPA(threshold, gpaScale)) {
                        s->display();
                        cout << "-----------------\n";
                    }
                }
            } else if (choice == 11) {
                string keyword;
                cout << "Enter name keyword to search: ";
                getline(cin, keyword);
                cout << "\nMatching Students:\n";
                for (const auto& [id, s] : students) {
                    if (nameMatches(s->getName(), keyword)) {
                        s->display();
                        cout << "-----------------\n";
                    }
                }
                cout << "Matching Faculty:\n";
                for (const auto& [id, f] : faculty) {
                    if (nameMatches(f->getName(), keyword)) {
                        f->display();
                        cout << "-----------------\n";
                    }
                }
            } else if (choice == 12) {
                string facKeyword;
                cout << "Enter instructor name or ID: ";
                getline(cin, facKeyword);
                cout << "Courses taught by '" << facKeyword << "':\n";
                for (const auto& [code, course] : courses) {
                    Faculty* fac = course->getInstructor();
                    if (fac->getName().find(facKeyword) != string::npos || fac->getId() == facKeyword) {
                        cout << "- " << course->getTitle() << " (" << code << ")\n";
                    }
                }
            } else if (choice == 13) {
                restoreBackup(students, courses, studentsBackup, coursesBackup);
                cout << "Undo complete. Last state restored.\n";
            } else if (choice == 14) {
                saveStudentsToFile(students, "students.txt");
                cout << "Students saved to students.txt\n";
            }
        } catch (const exception& e) {
            cerr << "Error: " << e.what() << endl;
        }
    } while (choice != 0);

    for (auto& p : students) delete p.second;
    for (auto& p : faculty) delete p.second;
    for (auto& p : courses) delete p.second;

    return 0;
}