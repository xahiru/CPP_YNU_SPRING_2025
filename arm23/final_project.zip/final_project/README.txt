University Student Management System (USMS)
===========================================


-----------------------------------------------------
HOW TO COMPILE
-----------------------------------------------------
Requirements:
- C++17-compatible compiler (e.g., g++)

Open terminal and run:
> g++ -std=c++17 main.cpp person.cpp student.cpp faculty.cpp course.cpp file_utils.cpp -o usms

-----------------------------------------------------
HOW TO RUN
-----------------------------------------------------

Windows:
> usms

Linux/macOS:
> ./usms

You will see a menu with numbered options to navigate the system.

-----------------------------------------------------
DEVELOPED WITH
-----------------------------------------------------
- Language: C++17  
- STL: vector, map, string, algorithm, iostream, fstream, filesystem  
- Exception Handling  
- Function and Class Templates  
- OOP: Inheritance, Polymorphism, Encapsulation  

-----------------------------------------------------
