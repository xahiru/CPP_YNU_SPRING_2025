#ifndef FILE_UTILS_H
#define FILE_UTILS_H

#include "student.h"
#include "course.h"
#include <map>
#include <vector>
#include <string>

void saveStudentsToFile(const std::map<std::string, Student*>& students, const std::string& filename);
void saveCourseSummaries(const std::map<std::string, Course*>& courses, const std::string& folderPrefix);
void backupData(const std::map<std::string, Student*>& students,
                const std::map<std::string, Course*>& courses,
                std::map<std::string, Student*>& studentBackup,
                std::map<std::string, Course*>& courseBackup);
void restoreBackup(std::map<std::string, Student*>& students,
                   std::map<std::string, Course*>& courses,
                   std::map<std::string, Student*>& studentBackup,
                   std::map<std::string, Course*>& courseBackup);
#endif