#include "course.h"
#include <iostream>
#include <fstream>
#include <iomanip>

Course::Course(std::string c, std::string t, Faculty* f)
    : code(c), title(t), instructor(f) {}

void Course::enrollStudent(Student* s) {
    enrolled.push_back(s);
}

std::string Course::getCode() const {
    return code;
}

std::string Course::getTitle() const {
    return title;
}

Faculty* Course::getInstructor() const {
    return instructor;
}

const std::vector<Student*>& Course::getEnrolled() const {
    return enrolled;
}

void Course::displayCourse() const {
    std::cout << "Course: " << code << " - " << title << std::endl;
    if (instructor) {
        std::cout << "Instructor: ";
        instructor->display();
    }
    std::cout << "Enrolled Students:\n";
    for (auto s : enrolled) {
        s->display();
    }
}

void Course::exportSummary(const std::string& filename) const {
    std::ofstream out(filename);
    if (!out) {
        std::cerr << "Failed to write course summary.\n";
        return;
    }

    out << "Course Summary\n==============\n";
    out << "Course Code: " << code << "\nTitle: " << title << "\n\n";
    if (instructor) {
        out << "Instructor: " << instructor->getName() << " (ID: " << instructor->getId() << ")\n\n";
    }

    out << "Enrolled Students:\n";
    for (const auto& s : enrolled) {
        out << " - " << s->getName() << " (ID: " << s->getId() << ", GPA: "
            << std::fixed << std::setprecision(2) << s->calculateGPA() << ")\n";
    }

    out.close();
}