#include "file_utils.h"
#include <fstream>
#include <iostream>
#include <filesystem>

void saveStudentsToFile(const std::map<std::string, Student*>& students, const std::string& filename) {
    std::ofstream file(filename);
    for (const auto& [id, student] : students) {
        file << student->getName() << "," << id << "," << student->getAge();
        for (const auto& [course, grade] : student->getGrades()) {
            file << "," << course << ":" << grade;
        }
        file << "\n";
    }
    file.close();
}

void saveCourseSummaries(const std::map<std::string, Course*>& courses, const std::string& folderPrefix) {
    std::filesystem::create_directory(folderPrefix);
    for (const auto& [code, course] : courses) {
        course->exportSummary(folderPrefix + "/" + code + "_summary.txt");
    }
}

void backupData(const std::map<std::string, Student*>& students,
                const std::map<std::string, Course*>& courses,
                std::map<std::string, Student*>& studentBackup,
                std::map<std::string, Course*>& courseBackup) {

    studentBackup.clear();
    for (const auto& [id, s] : students) {
        studentBackup[id] = new Student(*s);
    }

    courseBackup.clear();
    for (const auto& [code, c] : courses) {
        courseBackup[code] = new Course(*c); // Shallow copy is okay for undo purpose
    }
}

void restoreBackup(std::map<std::string, Student*>& students,
                   std::map<std::string, Course*>& courses,
                   std::map<std::string, Student*>& studentBackup,
                   std::map<std::string, Course*>& courseBackup) {

    for (auto& [id, s] : students) delete s;
    students = studentBackup;

    for (auto& [c, course] : courses) delete course;
    courses = courseBackup;

    studentBackup.clear();
    courseBackup.clear();
}