#include "student.h"
#include <iostream>
#include <iomanip>
#include <fstream>
#include <map>

Student::Student(std::string n, std::string i, int a) : Person(n, i, a) {}

void Student::addGrade(std::string course, char grade) {
    courseGrades[course] = grade;
}

float Student::calculateGPA(GPAScale scale) const {
    if (courseGrades.empty()) return 0.0;

    std::map<char, float> gradeMap4 = {
        {'A', 4.0}, {'B', 3.0}, {'C', 2.0}, {'D', 1.0}, {'F', 0.0}
    };
    std::map<char, float> gradeMapPercent = {
        {'A', 95}, {'B', 85}, {'C', 75}, {'D', 65}, {'F', 50}
    };

    float total = 0.0;
    for (const auto& entry : courseGrades) {
        total += (scale == SCALE_4) ? gradeMap4[entry.second] : gradeMapPercent[entry.second];
    }

    return total / courseGrades.size();
}

void Student::display() const {
    Person::display();
    std::cout << "Courses and Grades:\n";
    for (const auto& pair : courseGrades) {
        std::cout << "  " << pair.first << ": " << pair.second << "\n";
    }
    std::cout << std::fixed << std::setprecision(2)
              << "GPA (4.0 scale): " << calculateGPA(SCALE_4) << std::endl;
}

const std::map<std::string, char>& Student::getGrades() const {
    return courseGrades;
}

void Student::generateTranscript(const std::string& filename, GPAScale scale) const {
    std::ofstream out(filename);
    if (!out) {
        std::cerr << "Failed to write transcript.\n";
        return;
    }

    out << "Student Transcript\n";
    out << "==================\n";
    out << "Name: " << name << "\nID: " << id << "\nAge: " << age << "\n\n";
    out << "Courses and Grades:\n";

    for (const auto& pair : courseGrades) {
        out << "  " << pair.first << ": " << pair.second << "\n";
    }

    out << "\nGPA (" << (scale == SCALE_4 ? "4.0 scale" : "Percentage") << "): "
        << std::fixed << std::setprecision(2) << calculateGPA(scale) << "\n";

    out.close();
}

bool Student::hasHighGPA(float threshold, GPAScale scale) const {
    return calculateGPA(scale) >= threshold;
}