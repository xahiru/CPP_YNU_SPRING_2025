#ifndef STUDENT_H
#define STUDENT_H

#include "person.h"
#include <map>
#include <string>

enum GPAScale { SCALE_4, PERCENTAGE };

class Student : public Person {
private:
    std::map<std::string, char> courseGrades;

public:
    Student(std::string n = "", std::string i = "", int a = 0);

    void addGrade(std::string course, char grade);
    float calculateGPA(GPAScale scale = SCALE_4) const;
    void display() const override;
    void generateTranscript(const std::string& filename, GPAScale scale = SCALE_4) const;

    const std::map<std::string, char>& getGrades() const;
    bool hasHighGPA(float threshold, GPAScale scale = SCALE_4) const;
};

#endif