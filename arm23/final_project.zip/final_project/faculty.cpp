#include "faculty.h"
#include <iostream>

Faculty::Faculty(std::string n, std::string i, int a, std::string s)
    : Person(n, i, a), specialization(s) {}

void Faculty::display() const {
    Person::display();
    std::cout << "Specialization: " << specialization << std::endl;
}

std::string Faculty::getSpecialization() const {
    return specialization;
}