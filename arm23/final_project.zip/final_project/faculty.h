#ifndef FACULTY_H
#define FACULTY_H

#include "person.h"
#include <string>

class Faculty : public Person {
private:
    std::string specialization;

public:
    Faculty(std::string n = "", std::string i = "", int a = 0, std::string s = "");

    void display() const override;
    std::string getSpecialization() const;
};

#endif