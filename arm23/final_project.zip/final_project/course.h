#ifndef COURSE_H
#define COURSE_H

#include "faculty.h"
#include "student.h"
#include <vector>
#include <string>

class Course {
private:
    std::string code, title;
    Faculty* instructor;
    std::vector<Student*> enrolled;

public:
    Course(std::string c = "", std::string t = "", Faculty* f = nullptr);

    void enrollStudent(Student* s);
    std::string getCode() const;
    std::string getTitle() const;
    Faculty* getInstructor() const;
    const std::vector<Student*>& getEnrolled() const;

    void displayCourse() const;
    void exportSummary(const std::string& filename) const;
};

#endif