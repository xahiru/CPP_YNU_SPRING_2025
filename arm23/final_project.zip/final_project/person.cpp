#include "person.h"
#include <iostream>

Person::Person(std::string n, std::string i, int a) : name(n), id(i), age(a) {}

void Person::display() const {
    std::cout << "Name: " << name << ", ID: " << id << ", Age: " << age << std::endl;
}

std::string Person::getId() const {
    return id;
}

std::string Person::getName() const {
    return name;
}

int Person::getAge() const {
    return age;
}

Person::~Person() {}